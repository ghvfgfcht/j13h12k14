package talksum.talksum.service;

public interface STTservice {
    String executeSTT();
}
