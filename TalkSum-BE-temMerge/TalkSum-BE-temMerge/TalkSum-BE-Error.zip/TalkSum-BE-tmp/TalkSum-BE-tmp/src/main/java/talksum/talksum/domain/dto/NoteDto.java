package talksum.talksum.domain.dto;

import lombok.*;
import talksum.talksum.domain.entity.Member;
import talksum.talksum.domain.entity.Note;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class NoteDto {
    private String title;
    private boolean bookMark;
    private String noteContent;
    private Member author;

    /* DTO -> Entity */
    public Note toEntity(){
        return Note.builder()
                .title(title)
                .bookMark(bookMark)
                .noteContent(noteContent)
                .author(author)
                .build();
    }
}